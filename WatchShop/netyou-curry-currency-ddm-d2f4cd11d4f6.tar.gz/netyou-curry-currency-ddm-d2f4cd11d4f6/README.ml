# Curry is a currency drop down menu which plugs into jQuery
